# Replay the public evidence bundle

This archive is a deterministic, sanitized evidence subset. It contains no raw
chat transcript, private receipt, local path, credential, or third-party source
PDF. After extraction, change into `RW-10000069_PUBLIC_EVIDENCE_V1` and run:

```bash
shasum -a 256 -c BUNDLE_SHA256SUMS.txt
python3 verification/src/verify_claim_boundaries.py
```

The checksum command verifies the exact archived bytes. The Python check audits
the theorem and status boundaries. Neither command substitutes for mathematical
review, peer review, or proof-assistant verification.
