# Public evidence bundle manifest

Bundle ID: `RW-10000069_PUBLIC_EVIDENCE_V1`.

Every archived member is a regular file with a fixed ZIP timestamp and
mode. `BUNDLE_SHA256SUMS.txt` hashes every member except itself.

## Members

- `AI_DISCLOSURE.md`
- `BUNDLE_MANIFEST.md`
- `BUNDLE_SHA256SUMS.txt`
- `CITATION.cff`
- `CLAIMS_EVIDENCE_MATRIX.md`
- `LICENSE_STATUS.md`
- `PROBLEM_AND_PROOF.md`
- `PROVENANCE.md`
- `README.md`
- `REPLAY_README.md`
- `REPRODUCIBILITY.md`
- `SECURITY.md`
- `STATUS.md`
- `audits/README.md`
- `audits/public_safe_reports/MATHEMATICAL_AUDIT_STATUS.md`
- `audits/public_safe_reports/PRIORITY_AUDIT_ARCHITECTURE_2026-08-09.md`
- `audits/public_safe_reports/PRIORITY_AUDIT_EXACT_RESULT_2026-08-09.md`
- `audits/public_safe_reports/PRIORITY_AUDIT_STATUS.md`
- `formalization/DEPENDENCY_MAP.md`
- `formalization/FORMALIZATION_FEASIBILITY.md`
- `formalization/README.md`
- `formalization/THEOREM_SCOPE.md`
- `formalization/aristotle/ARISTOTLE_CORE_PROMPT.md`
- `formalization/aristotle/ARISTOTLE_SUBMISSION_RECEIPT.md`
- `formalization/lean/README.md`
- `paper/BUILD.md`
- `paper/BUILD_LOG.txt`
- `paper/BUILD_STATUS.md`
- `paper/CLAIM_SCOPE_AND_LIMITATIONS.md`
- `paper/HOSTILE_MANUSCRIPT_AUDIT_PROMPT.md`
- `paper/PDF_PREFLIGHT.md`
- `paper/README.md`
- `paper/SOURCE_COMPARISON.md`
- `paper/SOURCE_QA.md`
- `paper/manuscript.pdf`
- `paper/manuscript.tex`
- `paper/references.bib`
- `proof/CANONICAL_REPAIRED_PROOF_V1.md`
- `release/BADGE_ACTIVATION.md`
- `release/HUMAN_RELEASE_CHECKLIST.md`
- `release/README.md`
- `release/RELEASE_NOTES_v1.0.0.md`
- `verification/README.md`
- `verification/src/verify_claim_boundaries.py`
